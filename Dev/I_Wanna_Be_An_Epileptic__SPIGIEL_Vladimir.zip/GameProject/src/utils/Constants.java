package utils;

public class Constants {
	public static int WIDTH_CANVAS = 420;
	public static int HEIGHT_CANVAS = 210;
}
