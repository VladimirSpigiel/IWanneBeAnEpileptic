package event;

import java.awt.event.KeyListener;

public interface KeyEvent extends KeyListener{
	
}
