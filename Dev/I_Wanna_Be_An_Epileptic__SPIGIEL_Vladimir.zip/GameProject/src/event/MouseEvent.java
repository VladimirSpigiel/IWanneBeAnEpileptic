package event;

import java.awt.event.MouseListener;

public interface MouseEvent extends MouseListener {

}
