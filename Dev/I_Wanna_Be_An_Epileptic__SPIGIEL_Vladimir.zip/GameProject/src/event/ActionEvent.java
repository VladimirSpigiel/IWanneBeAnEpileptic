package event;

import java.awt.event.ActionListener;

public interface ActionEvent extends ActionListener {

}
