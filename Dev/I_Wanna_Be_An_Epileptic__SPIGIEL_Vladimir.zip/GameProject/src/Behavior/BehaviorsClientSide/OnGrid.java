package Behavior.BehaviorsClientSide;

import kernel.Game;
import Model.Client;
import Model.Grid;

public class OnGrid extends BehaviorClient {

	public OnGrid(Client c) {
		super(c, true);
	}

	@Override
	public void execute() {
		Grid g = (Grid) getObject();
		Game.getInstance().setGrid(g);	
	}
	
	
}
