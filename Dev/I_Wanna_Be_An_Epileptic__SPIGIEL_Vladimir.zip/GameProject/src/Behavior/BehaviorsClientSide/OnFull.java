package Behavior.BehaviorsClientSide;

import Model.Client;

public class OnFull extends BehaviorClient {

	public OnFull(Client c) {
		super(c, false);
	}

	@Override
	public void execute() {
		//
	}

}
