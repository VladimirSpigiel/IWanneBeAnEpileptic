package Behavior.BehaviorsClientSide;


import Model.Client;


public class OnJoined extends BehaviorClient {

	public OnJoined(Client c) {
		super(c, false);
	}

	@Override
	public void execute() {
				
	}
	
	

}