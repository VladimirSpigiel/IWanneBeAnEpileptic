package Model;

public enum Difficulty {
	
	EASY(), MEDIUM(), HARD();
		
}
