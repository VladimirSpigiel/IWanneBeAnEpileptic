package Controller;


public interface GameState {
	public void entered();
	public void leaving();
	public void update();
}
